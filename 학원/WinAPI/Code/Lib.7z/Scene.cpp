#include "Scene.h"

namespace JEngine
{
	Scene::Scene()
	{
	}


	Scene::~Scene()
	{
	}
}
